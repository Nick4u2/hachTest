from django.apps import AppConfig


class MainNmConfig(AppConfig):
    name = 'main_nm'
