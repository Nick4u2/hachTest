from django.shortcuts import render
from . import models


def dashboard(request):

    patient = models.Patient.objects.first()

    appointments = models.Appointment.objects.filter(
        patient=patient
    )

    documents = models.MedicalDocument.objects.filter(
        patient=patient
    )

    radiation = models.RadiationProcedure.objects.filter(
        patient=patient
    )

    context = {
        'patient': patient,
        'appointments': appointments,
        'documents': documents,
        'radiation': radiation,
    }

    return render(
        request,
        'patients/patient_dashboard.html',
        context = context
    )