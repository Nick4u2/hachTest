from django.urls import path
from .views import dashboard

urlpatterns = [
    path('patient_dashboard/', dashboard, name='dashboard'),
]