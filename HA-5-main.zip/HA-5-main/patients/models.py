from django.db import models


class Patient(models.Model):

    full_name = models.CharField(max_length=255)
    birth_date = models.DateField()
    phone = models.CharField(max_length=30)
    diagnosis = models.CharField(max_length=255)
    blood_group = models.CharField(max_length=20)
    weight = models.FloatField()
    height = models.FloatField()
    allergies = models.TextField(blank=True)
    chronic_diseases = models.TextField(blank=True)
    radiation_dose = models.FloatField(default=0)

    def __str__(self):
        return self.full_name


class Appointment(models.Model):

    STATUS_CHOICES = (
        ('confirmed', 'Confirmed'),
        ('pending', 'Pending'),
    )

    patient = models.ForeignKey(
        Patient,
        on_delete=models.CASCADE
    )

    title = models.CharField(max_length=255)
    doctor = models.CharField(max_length=255)
    room = models.CharField(max_length=50)
    date = models.DateTimeField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES)

    def __str__(self):
        return self.title


class MedicalDocument(models.Model):

    patient = models.ForeignKey(
        Patient,
        on_delete=models.CASCADE
    )

    title = models.CharField(max_length=255)
    file = models.FileField(upload_to='documents/')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


class RadiationProcedure(models.Model):

    patient = models.ForeignKey(
        Patient,
        on_delete=models.CASCADE
    )

    procedure_name = models.CharField(max_length=255)
    dose = models.FloatField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.procedure_name