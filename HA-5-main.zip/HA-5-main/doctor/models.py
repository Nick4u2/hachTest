from django.db import models


class Patient(models.Model):
    name = models.CharField(max_length=255)
    age = models.IntegerField()
    height = models.IntegerField()
    weight = models.IntegerField()

    blood_type = models.CharField(max_length=10)

    diagnosis = models.CharField(max_length=255)
    stage = models.CharField(max_length=20)

    contact = models.CharField(max_length=100)

    first_visit = models.DateField()

    allergies = models.TextField(blank=True)
    chronic_diseases = models.TextField(blank=True)

    notes = models.TextField(blank=True)

    def __str__(self):
        return self.name


class Appointment(models.Model):
    patient = models.ForeignKey(
        Patient,
        on_delete=models.CASCADE
    )

    appointment_time = models.DateTimeField()

    appointment_type = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.patient.name} - {self.appointment_time}"


class Treatment(models.Model):
    patient = models.ForeignKey(
        Patient,
        on_delete=models.CASCADE
    )

    treatment_method = models.CharField(max_length=255)

    dosage = models.CharField(max_length=255)

    radiation_dose = models.FloatField(
        null=True,
        blank=True
    )

    duration = models.CharField(max_length=255)

    recommendations = models.TextField(blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.treatment_method