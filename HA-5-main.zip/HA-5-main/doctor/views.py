from django.shortcuts import render, redirect, get_object_or_404
from . import models


def dashboard(request):

    patients = models.Patient.objects.all()

    selected_patient = patients.first()

    appointments = models.Appointment.objects.all().order_by("appointment_time")

    context = {
        "patients": patients,
        "patient": selected_patient,
        "appointments": appointments,
    }

    return render(request, "doctor/dashboard.html", context=context)